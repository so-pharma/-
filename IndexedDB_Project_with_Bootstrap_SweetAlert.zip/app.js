
let db;

// فتح قاعدة البيانات وتخزين المستخدمين
let request = indexedDB.open("LoginDB", 1);

request.onupgradeneeded = function(event) {
    db = event.target.result;

    // إنشاء جدول للمستخدمين
    let userStore = db.createObjectStore("users", { keyPath: "username" });
    userStore.add({ username: 'ayman' });
    userStore.add({ username: 'aya' });
    userStore.add({ username: '1' });
};

request.onsuccess = function(event) {
    db = event.target.result;
    checkLoggedInUser();
};

request.onerror = function(event) {
    console.error("خطأ في فتح قاعدة البيانات: ", event.target.errorCode);
};

function checkLoggedInUser() {
    let loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
        Swal.fire({
            icon: 'success',
            title: `مرحبًا مرة أخرى، ${loggedInUser}!`,
            showConfirmButton: false,
            timer: 1500
        });
        document.getElementById('loginSection').style.display = 'none';
    }
}

document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    let username = document.getElementById('username').value.trim().toLowerCase();

    let transaction = db.transaction(["users"], "readonly");
    let objectStore = transaction.objectStore("users");
    let request = objectStore.get(username);

    request.onsuccess = function(event) {
        if (event.target.result) {
            localStorage.setItem('loggedInUser', username);
            Swal.fire({
                icon: 'success',
                title: `مرحبًا، ${username}!`,
                showConfirmButton: false,
                timer: 1500
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'خطأ',
                text: 'اسم المستخدم غير مسموح.'
            });
        }
    };

    request.onerror = function() {
        Swal.fire({
            icon: 'error',
            title: 'خطأ',
            text: 'حدث خطأ في تسجيل الدخول.'
        });
    };
});
